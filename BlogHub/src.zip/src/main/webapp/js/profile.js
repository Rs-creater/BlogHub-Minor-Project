
  const modal = document.getElementById('updateModal');
  const openBtn = document.getElementById('openUpdateBtn');
  const closeBtn = document.getElementById('closeModal');
  const saveEditBtn = document.getElementById('saveEdit');

  openBtn.addEventListener('click', () => {
    modal.style.display = 'flex';
  });

  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  window.addEventListener('click', (e) => {
    if (e.target == modal) {
      modal.style.display = 'none';
    }
  });

 
// New: Handle Edit & Delete Buttons
const editButtons = document.querySelectorAll('.btn.edit');
const deleteButtons = document.querySelectorAll('.btn.delete');

editButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    alert('Edit button clicked!');
    // You can open a modal and populate fields with post data here
  });
});

deleteButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    const postCard = btn.closest('.post-card');
    if (confirm('Are you sure you want to delete this post?')) {
      postCard.remove();
    }
  });
});
  
