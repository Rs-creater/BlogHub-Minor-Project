// DOM elements
document.addEventListener('DOMContentLoaded', function() {
  // Session Management
  initSessionManagement();
  
  // Settings Navigation
  initSettingsNav();
  
  // Theme Switcher
  initThemeSwitcher();
  
  // Color Scheme Selector
  initColorSchemeSelector();
  
  // Font Size Slider
  initFontSizeSlider();
  
  // Layout Density Options
  initLayoutDensityOptions();
  
  // Password Visibility Toggle
  initPasswordVisibilityToggle();
  
  // Profile Picture Upload
  initProfilePictureUpload();
  
  // Form Validation
  initFormValidation();
  
  // API Key Management
  initAPIKeyManagement();
  
  // Notification Effects
  initNotificationEffects();
  
  // Add interactive animations
  initAnimations();
  
  // Search functionality
  initSearchFunctionality();
  
  // Session timeout warning
  initSessionTimeoutWarning();
});

// Session Management Functions
function initSessionManagement() {
  // Check if session exists
  const sessionToken = localStorage.getItem('sessionToken');
  const sessionExpiry = localStorage.getItem('sessionExpiry');
  const userData = JSON.parse(localStorage.getItem('userData'));
  
  if (!sessionToken || new Date().getTime() > sessionExpiry) {
      // For demo purposes, we'll just create a session rather than redirecting to login
      createDemoSession();
  } else {
      // Populate user data from session
      populateUserData(userData);
  }
  
  // Auto-save settings changes to session
  document.querySelectorAll('input, textarea, select').forEach(element => {
      element.addEventListener('change', saveFieldToSession);
  });
  
  // Set up session expiry handler
  const remainingTime = sessionExpiry - new Date().getTime();
  if (remainingTime > 0) {
      setTimeout(showSessionExpiryWarning, Math.max(0, remainingTime - 5 * 60 * 1000)); // 5 minutes before expiry
  }
}

function createDemoSession() {
  const expiryTime = new Date().getTime() + (2 * 60 * 60 * 1000); // 2 hours
  const userData = {
      displayName: "Alex Morgan",
      username: "alexwrites",
      email: "alex@example.com",
      bio: "Tech enthusiast and writer. Sharing insights about web development, AI, and digital marketing.",
      location: "San Francisco, CA",
      website: "https://alexmorgan.dev",
      profileImage: "/api/placeholder/100/100",
      preferences: {
          theme: "light",
          accentColor: "blue",
          fontSize: 16,
          layoutDensity: "comfortable"
      },
      notifications: {
          newComments: true,
          likesShares: true,
          newFollowers: true,
          newsletter: false,
          pushEnabled: true,
          frequency: "daily"
      }
  };
  
  localStorage.setItem('sessionToken', generateRandomToken());
  localStorage.setItem('sessionExpiry', expiryTime);
  localStorage.setItem('userData', JSON.stringify(userData));
  
  populateUserData(userData);
}

function generateRandomToken() {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

function populateUserData(userData) {
  if (!userData) return;
  
  // Profile information
  if (document.getElementById('displayName')) document.getElementById('displayName').value = userData.displayName;
  if (document.getElementById('username')) document.getElementById('username').value = userData.username;
  if (document.getElementById('email')) document.getElementById('email').value = userData.email;
  if (document.getElementById('bio')) document.getElementById('bio').value = userData.bio;
  if (document.getElementById('location')) document.getElementById('location').value = userData.location;
  if (document.getElementById('website')) document.getElementById('website').value = userData.website;
  
  // Update sidebar profile
  document.querySelectorAll('.profile-info h3').forEach(el => {
      el.textContent = userData.displayName;
  });
  
  document.querySelectorAll('.profile-info p').forEach(el => {
      el.textContent = '@' + userData.username;
  });
  
  // Update preferences if they exist
  if (userData.preferences) {
      // Theme
      const theme = userData.preferences.theme;
      document.querySelectorAll('.theme-card').forEach(card => {
          card.classList.remove('active');
          if (card.dataset.theme === theme) {
              card.classList.add('active');
          }
      });
      
      // Apply theme to document
      if (theme === 'dark') {
          document.body.setAttribute('data-theme', 'dark');
      } else {
          document.body.removeAttribute('data-theme');
      }
      
      // Accent color
      const accentColor = userData.preferences.accentColor;
      document.querySelectorAll('.color-button').forEach(btn => {
          btn.classList.remove('active');
          if (btn.classList.contains(accentColor)) {
              btn.classList.add('active');
          }
      });
      
      // Font size
      const fontSize = userData.preferences.fontSize;
      if (document.getElementById('fontSizeSlider')) {
          document.getElementById('fontSizeSlider').value = fontSize;
          document.documentElement.style.setProperty('--base-font-size', fontSize + 'px');
      }
      
      // Layout density
      const density = userData.preferences.layoutDensity;
      document.querySelectorAll('.layout-options .btn-option').forEach((btn, index) => {
          btn.classList.remove('active');
          if ((density === 'compact' && index === 0) ||
              (density === 'comfortable' && index === 1) ||
              (density === 'spacious' && index === 2)) {
              btn.classList.add('active');
          }
      });
  }
  
  // Update notification preferences
  if (userData.notifications) {
      const notifs = userData.notifications;
      const checkboxes = {
          'New Comments': notifs.newComments,
          'Likes & Shares': notifs.likesShares,
          'New Followers': notifs.newFollowers,
          'Newsletter & Updates': notifs.newsletter,
          'Enable Push Notifications': notifs.pushEnabled
      };
      
      document.querySelectorAll('.toggle-option').forEach(option => {
          const title = option.querySelector('h4').textContent;
          const checkbox = option.querySelector('input[type="checkbox"]');
          if (checkbox && title in checkboxes) {
              checkbox.checked = checkboxes[title];
          }
      });
      
      if (document.getElementById('frequency')) {
          document.getElementById('frequency').value = notifs.frequency;
      }
  }
}

function saveFieldToSession(event) {
  const element = event.target;
  const userData = JSON.parse(localStorage.getItem('userData')) || {};
  
  // Determine which setting to update based on input id or other attributes
  if (element.id === 'displayName') userData.displayName = element.value;
  if (element.id === 'username') userData.username = element.value;
  if (element.id === 'email') userData.email = element.value;
  if (element.id === 'bio') userData.bio = element.value;
  if (element.id === 'location') userData.location = element.value;
  if (element.id === 'website') userData.website = element.value;
  
  // For notification toggle switches
  if (element.type === 'checkbox' && element.closest('.toggle-option')) {
      const title = element.closest('.toggle-option').querySelector('h4').textContent;
      
      if (!userData.notifications) userData.notifications = {};
      
      if (title === 'New Comments') userData.notifications.newComments = element.checked;
      if (title === 'Likes & Shares') userData.notifications.likesShares = element.checked;
      if (title === 'New Followers') userData.notifications.newFollowers = element.checked;
      if (title === 'Newsletter & Updates') userData.notifications.newsletter = element.checked;
      if (title === 'Enable Push Notifications') userData.notifications.pushEnabled = element.checked;
  }
  
  // For notification frequency dropdown
  if (element.id === 'frequency') {
      if (!userData.notifications) userData.notifications = {};
      userData.notifications.frequency = element.value;
  }
  
  // For appearance settings
  if (element.id === 'fontSizeSlider') {
      if (!userData.preferences) userData.preferences = {};
      userData.preferences.fontSize = parseInt(element.value);
  }
  
  // Save the updated user data
  localStorage.setItem('userData', JSON.stringify(userData));
  
  // Show saved feedback
  showSavedFeedback();
}

function showSavedFeedback() {
  // Create or get save indicator
  let saveIndicator = document.getElementById('saveIndicator');
  
  if (!saveIndicator) {
      saveIndicator = document.createElement('div');
      saveIndicator.id = 'saveIndicator';
      saveIndicator.className = 'save-indicator';
      saveIndicator.textContent = 'Changes saved';
      document.body.appendChild(saveIndicator);
      
      // Style the indicator
      saveIndicator.style.position = 'fixed';
      saveIndicator.style.bottom = '20px';
      saveIndicator.style.right = '20px';
      saveIndicator.style.backgroundColor = 'var(--success-color)';
      saveIndicator.style.color = 'white';
      saveIndicator.style.padding = '8px 16px';
      saveIndicator.style.borderRadius = 'var(--border-radius)';
      saveIndicator.style.opacity = '0';
      saveIndicator.style.transition = 'opacity 0.5s ease';
      saveIndicator.style.zIndex = '1000';
  }
  
  // Show and then hide the indicator
  saveIndicator.style.opacity = '1';
  
  clearTimeout(window.saveTimeout);
  window.saveTimeout = setTimeout(() => {
      saveIndicator.style.opacity = '0';
  }, 2000);
}

function showSessionExpiryWarning() {
  // Create session warning element
  const warningEl = document.createElement('div');
  warningEl.className = 'session-warning';
  warningEl.innerHTML = `
      <div class="session-warning-content">
          <i class="fas fa-exclamation-triangle"></i>
          <h3>Session Expiring Soon</h3>
          <p>Your session will expire in 5 minutes. Would you like to extend?</p>
          <div class="session-warning-actions">
              <button class="btn btn-primary extend-session">Extend Session</button>
              <button class="btn btn-outline logout-session">Logout</button>
          </div>
      </div>
  `;
  
  // Style the warning
  warningEl.style.position = 'fixed';
  warningEl.style.top = '0';
  warningEl.style.left = '0';
  warningEl.style.width = '100%';
  warningEl.style.height = '100%';
  warningEl.style.backgroundColor = 'rgba(0,0,0,0.5)';
  warningEl.style.display = 'flex';
  warningEl.style.alignItems = 'center';
  warningEl.style.justifyContent = 'center';
  warningEl.style.zIndex = '2000';
  
  const content = warningEl.querySelector('.session-warning-content');
  content.style.backgroundColor = 'var(--card-bg)';
  content.style.padding = '24px';
  content.style.borderRadius = 'var(--border-radius)';
  content.style.width = '400px';
  content.style.textAlign = 'center';
  
  // Add to document
  document.body.appendChild(warningEl);
  
  // Handle extend session button
  warningEl.querySelector('.extend-session').addEventListener('click', function() {
      const expiryTime = new Date().getTime() + (2 * 60 * 60 * 1000); // 2 more hours
      localStorage.setItem('sessionExpiry', expiryTime);
      
      warningEl.remove();
      
      // Show extended notification
      const notification = document.createElement('div');
      notification.className = 'notification';
      notification.textContent = 'Session extended by 2 hours';
      notification.style.position = 'fixed';
      notification.style.top = '20px';
      notification.style.right = '20px';
      notification.style.backgroundColor = 'var(--success-color)';
      notification.style.color = 'white';
      notification.style.padding = '10px 20px';
      notification.style.borderRadius = 'var(--border-radius)';
      notification.style.zIndex = '1000';
      notification.style.opacity = '0';
      notification.style.transition = 'opacity 0.3s ease';
      
      document.body.appendChild(notification);
      
      setTimeout(() => {
          notification.style.opacity = '1';
      }, 100);
      
      setTimeout(() => {
          notification.style.opacity = '0';
          setTimeout(() => notification.remove(), 300);
      }, 3000);
      
      // Set up next warning
      setTimeout(showSessionExpiryWarning, 2 * 60 * 60 * 1000 - 5 * 60 * 1000);
  });
  
  // Handle logout button
  warningEl.querySelector('.logout-session').addEventListener('click', function() {
      localStorage.removeItem('sessionToken');
      localStorage.removeItem('sessionExpiry');
      // In a real app, you would redirect to login page
      // For demo, we'll just recreate the session
      createDemoSession();
      warningEl.remove();
  });
}

// Settings Navigation Functions
function initSettingsNav() {
  const settingsNavItems = document.querySelectorAll('.settings-nav li');
  const settingsSections = document.querySelectorAll('.settings-section');
  
  settingsNavItems.forEach(item => {
      item.addEventListener('click', function() {
          const targetSectionId = this.getAttribute('data-section');
          
          // Update navigation active state
          settingsNavItems.forEach(item => item.classList.remove('active'));
          this.classList.add('active');
          
          // Show target section
          settingsSections.forEach(section => section.classList.remove('active'));
          document.getElementById(targetSectionId).classList.add('active');
          
          // Add animation to the section
          document.getElementById(targetSectionId).style.animation = 'fadeIn 0.3s forwards';
          
          // Update URL hash for direct links
          window.location.hash = targetSectionId;
      });
  });
  
  // Check for URL hash on page load
  if (window.location.hash) {
      const targetSectionId = window.location.hash.substring(1);
      const targetNavItem = document.querySelector(`.settings-nav li[data-section="${targetSectionId}"]`);
      
      if (targetNavItem) {
          targetNavItem.click();
      }
  }
}

// Theme Switcher Function
function initThemeSwitcher() {
  const themeCards = document.querySelectorAll('.theme-card');
  
  themeCards.forEach(card => {
      card.addEventListener('click', function() {
          // Update active state
          themeCards.forEach(c => c.classList.remove('active'));
          this.classList.add('active');
          
          const theme = this.getAttribute('data-theme');
          
          // Apply theme
          if (theme === 'dark') {
              document.body.setAttribute('data-theme', 'dark');
          } else if (theme === 'light') {
              document.body.removeAttribute('data-theme');
          } else if (theme === 'auto') {
              // Check system preference
              if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                  document.body.setAttribute('data-theme', 'dark');
              } else {
                  document.body.removeAttribute('data-theme');
              }
              
              // Listen for system changes
              window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
                  if (document.querySelector('.theme-card.active').getAttribute('data-theme') === 'auto') {
                      if (event.matches) {
                          document.body.setAttribute('data-theme', 'dark');
                      } else {
                          document.body.removeAttribute('data-theme');
                      }
                  }
              });
          }
          
          // Save to user preferences
          const userData = JSON.parse(localStorage.getItem('userData')) || {};
          if (!userData.preferences) userData.preferences = {};
          userData.preferences.theme = theme;
          localStorage.setItem('userData', JSON.stringify(userData));
          
          // Show visual feedback
          showSavedFeedback();
      });
  });
}

// Color Scheme Selector Function
function initColorSchemeSelector() {
  const colorButtons = document.querySelectorAll('.color-button');
  
  colorButtons.forEach(button => {
      button.addEventListener('click', function() {
          // Update active state
          colorButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');
          
          const color = this.getAttribute('data-color');
          
          // Apply color scheme (in a real app, this would update CSS variables)
          let primaryColor;
          let primaryHover;
          
          switch (color) {
              case 'blue':
                  primaryColor = '#4a6cf7';
                  primaryHover = '#3a5cef';
                  break;
              case 'purple':
                  primaryColor = '#6f42c1';
                  primaryHover = '#5e37a6';
                  break;
              case 'teal':
                  primaryColor = '#20c997';
                  primaryHover = '#1ba87f';
                  break;
              case 'orange':
                  primaryColor = '#fd7e14';
                  primaryHover = '#e56c02';
                  break;
              case 'green':
                  primaryColor = '#28a745';
                  primaryHover = '#218838';
                  break;
          }
          
          // Update CSS variables
          document.documentElement.style.setProperty('--primary-color', primaryColor);
          document.documentElement.style.setProperty('--primary-hover', primaryHover);
          
          // Save to user preferences
          const userData = JSON.parse(localStorage.getItem('userData')) || {};
          if (!userData.preferences) userData.preferences = {};
          userData.preferences.accentColor = color;
          localStorage.setItem('userData', JSON.stringify(userData));
          
          // Show visual feedback
          showSavedFeedback();
      });
  });
}

// Font Size Slider Function
function initFontSizeSlider() {
  const fontSizeSlider = document.getElementById('fontSizeSlider');
  
  if (fontSizeSlider) {
      // Set initial CSS variable if not already set
      if (!document.documentElement.style.getPropertyValue('--base-font-size')) {
          document.documentElement.style.setProperty('--base-font-size', fontSizeSlider.value + 'px');
      }
      
      fontSizeSlider.addEventListener('input', function() {
          // Update font size CSS variable
          document.documentElement.style.setProperty('--base-font-size', this.value + 'px');
          
          // For demo purposes, we'll scale some specific elements
          const fontSizeFactor = this.value / 16; // Base the scaling on 16px
          
          document.querySelectorAll('.settings-section h2').forEach(el => {
              el.style.fontSize = (22 * fontSizeFactor) + 'px';
          });
          
          document.querySelectorAll('.settings-section h3').forEach(el => {
              el.style.fontSize = (18 * fontSizeFactor) + 'px';
          });
          
          document.querySelectorAll('.settings-section p, .toggle-info p').forEach(el => {
              el.style.fontSize = (14 * fontSizeFactor) + 'px';
          });
      });
      
      fontSizeSlider.addEventListener('change', function() {
          // Save to user preferences
          const userData = JSON.parse(localStorage.getItem('userData')) || {};
          if (!userData.preferences) userData.preferences = {};
          userData.preferences.fontSize = parseInt(this.value);
          localStorage.setItem('userData', JSON.stringify(userData));
          
          // Show visual feedback
          showSavedFeedback();
      });
  }
}

// Layout Density Options Function
function initLayoutDensityOptions() {
  const densityButtons = document.querySelectorAll('.layout-options .btn-option');
  
  densityButtons.forEach((button, index) => {
      button.addEventListener('click', function() {
          // Update active state
          densityButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');
          
          // Apply density changes
          let spacingFactor;
          let density;
          
          if (index === 0) {
              // Compact
              spacingFactor = 0.8;
              density = 'compact';
          } else if (index === 1) {
              // Comfortable (default)
              spacingFactor = 1;
              density = 'comfortable';
          } else {
              // Spacious
              spacingFactor = 1.2;
              density = 'spacious';
          }
          
          // Update CSS variables
          document.documentElement.style.setProperty('--spacing-xs', (4 * spacingFactor) + 'px');
          document.documentElement.style.setProperty('--spacing-sm', (8 * spacingFactor) + 'px');
          document.documentElement.style.setProperty('--spacing-md', (16 * spacingFactor) + 'px');
          document.documentElement.style.setProperty('--spacing-lg', (24 * spacingFactor) + 'px');
          document.documentElement.style.setProperty('--spacing-xl', (32 * spacingFactor) + 'px');
          
          // Save to user preferences
          const userData = JSON.parse(localStorage.getItem('userData')) || {};
          if (!userData.preferences) userData.preferences = {};
          userData.preferences.layoutDensity = density;
          localStorage.setItem('userData', JSON.stringify(userData));
          
          // Show visual feedback
          showSavedFeedback();
      });
  });
}

// Password Visibility Toggle Function
function initPasswordVisibilityToggle() {
  const visibilityToggles = document.querySelectorAll('.toggle-visibility');
  
  visibilityToggles.forEach(toggle => {
      toggle.addEventListener('click', function() {
          const inputField = this.previousElementSibling;
          const icon = this.querySelector('i');
          
          if (inputField.type === 'password') {
              inputField.type = 'text';
              icon.classList.remove('fa-eye');
              icon.classList.add('fa-eye-slash');
              
              // Auto-hide after 3 seconds
              setTimeout(() => {
                  inputField.type = 'password';
                  icon.classList.remove('fa-eye-slash');
                  icon.classList.add('fa-eye');
              }, 3000);
          } else {
              inputField.type = 'password';
              icon.classList.remove('fa-eye-slash');
              icon.classList.add('fa-eye');
          }
      });
  });
  
  // Copy API key functionality
  const copyButtons = document.querySelectorAll('.api-key .btn-outline');
  copyButtons.forEach(button => {
      button.addEventListener('click', function() {
          const keyInput = this.closest('.api-key').querySelector('input');
          keyInput.select();
          document.execCommand('copy');
          
          // Show feedback
          const originalText = this.textContent;
          this.textContent = 'Copied!';
          setTimeout(() => {
              this.textContent = originalText;
          }, 2000);
      });
  });
}

// Profile Picture Upload Function
function initProfilePictureUpload() {
  const avatarOverlay = document.querySelector('.avatar-overlay');
  const changePhotoBtn = document.querySelector('.profile-setting .btn-outline');
  
  if (avatarOverlay) {
      avatarOverlay.addEventListener('click', triggerFileUpload);
  }
  
  if (changePhotoBtn) {
      changePhotoBtn.addEventListener('click', triggerFileUpload);
  }
  
  function triggerFileUpload() {
      // Create hidden file input
      let fileInput = document.getElementById('profilePhotoInput');
      
      if (!fileInput) {
          fileInput = document.createElement('input');
          fileInput.type = 'file';
          fileInput.id = 'profilePhotoInput';
          fileInput.accept = 'image/*';
          fileInput.style.display = 'none';
          document.body.appendChild(fileInput);
          
          fileInput.addEventListener('change', function(e) {
              if (this.files && this.files[0]) {
                  const file = this.files[0];
                  
                  // In a real app, you would upload the file to a server
                  // For this demo, we'll simulate with a placeholder
                  
                  // Show loading state
                  const profileImages = document.querySelectorAll('.profile-avatar img, .profile-pic img');
                  profileImages.forEach(img => {
                      img.style.opacity = '0.5';
                  });
                  
                  // Simulate upload delay
                  setTimeout(() => {
                      // Generate a random number for placeholder to simulate changing the image
                      const random = Math.floor(Math.random() * 1000);
                      
                      profileImages.forEach(img => {
                          img.src = `/api/placeholder/${img.width}/${img.height}?r=${random}`;
                          img.style.opacity = '1';
                      });
                      
                      // Save to user preferences
                      const userData = JSON.parse(localStorage.getItem('userData')) || {};
                      userData.profileImage = `/api/placeholder/100/100?r=${random}`;
                      localStorage.setItem('userData', JSON.stringify(userData));
                      
                      // Show notification
                      const notification = document.createElement('div');
                      notification.className = 'notification';
                      notification.textContent = 'Profile photo updated successfully';
                      notification.style.position = 'fixed';
                      notification.style.top = '20px';
                      notification.style.right = '20px';
                      notification.style.backgroundColor = 'var(--success-color)';
                      notification.style.color = 'white';
                      notification.style.padding = '10px 20px';
                      notification.style.borderRadius = 'var(--border-radius)';
                      notification.style.zIndex = '1000';
                      notification.style.opacity = '0';
                      notification.style.transition = 'opacity 0.3s ease';
                      
                      document.body.appendChild(notification);
                      
                      setTimeout(() => {
                          notification.style.opacity = '1';
                      }, 100);
                      
                      setTimeout(() => {
                          notification.style.opacity = '0';
                          setTimeout(() => notification.remove(), 300);
                      }, 3000);
                  }, 1500);
              }
          });
      }
      
      fileInput.click();
  }
}

// Form Validation Function
function initFormValidation() {
  // Password fields validation
  const passwordForm = document.querySelector('.security-section button.btn-primary');
  
  if (passwordForm) {
      passwordForm.addEventListener('click', function(e) {
          e.preventDefault();
          
          const currentPassword = document.getElementById('current-password');
          const newPassword = document.getElementById('new-password');
          const confirmPassword = document.getElementById('confirm-password');
          
          // Clear previous error messages
          document.querySelectorAll('.password-error').forEach(el => el.remove());
          
          let hasErrors = false;
          
          // Check if current password is filled
          if (!currentPassword.value) {
              showError(currentPassword, 'Please enter your current password');
              hasErrors = true;
          }
          
          // Check if new password is filled
          if (!newPassword.value) {
              showError(newPassword, 'Please enter a new password');
              hasErrors = true;
          } else if (newPassword.value.length < 8) {
              showError(newPassword, 'Password must be at least 8 characters');
              hasErrors = true;
          }
          
          // Check if passwords match
          if (newPassword.value !== confirmPassword.value) {
              showError(confirmPassword, 'Passwords do not match');
              hasErrors = true;
          }
          
          if (!hasErrors) {
              // Simulate password update
              setTimeout(() => {
                  // Show success message
                  const successMessage = document.createElement('div');
                  successMessage.className = 'password-success';
                  successMessage.textContent = 'Password updated successfully';
                  successMessage.style.color = 'var(--success-color)';
                  successMessage.style.marginTop = '10px';
                  passwordForm.after(successMessage);
                  
                  // Clear password fields
                  currentPassword.value = '';
                  newPassword.value = '';
                  confirmPassword.value = '';
                  
                  // Remove success message after 3 seconds
                  setTimeout(() => {
                      successMessage.remove();
                  }, 3000);
              }, 500);
          }
          
          function showError(element, message) {
              const errorMessage = document.createElement('div');
              errorMessage.className = 'password-error';
              errorMessage.textContent = message;
              errorMessage.style.color = 'var(--danger-color)';
              errorMessage.style.fontSize = '12px';
              errorMessage.style.marginTop = '5px';
              
              element.style.borderColor = 'var(--danger-color)';
              element.parentNode.appendChild(errorMessage);
              
              // Clear error state on input
              element.addEventListener('input', function() {
                  this.style.borderColor = '';
                  const error = this.parentNode.querySelector('.password-error');
                  if (error) error.remove();
              }, { once: true });
          }
      });
  }
  
  // Profile form validation
  const profileForm = document.querySelector('#profile button.btn-primary');
  
  if (profileForm) {
      profileForm.addEventListener('click', function(e) {
          e.preventDefault();
          
          const displayName = document.getElementById('displayName');
          const username = document.getElementById('username');
          const email = document.getElementById('email');
          
          // Clear previous error messages
          document.querySelectorAll('.profile-error').forEach(el => el.remove());
          
          let hasErrors = false;
          
          // Check display name
          if (!displayName.value) {
              showError(displayName, 'Display name cannot be empty');
              hasErrors = true;
          }
          
          // Check username
          if (!username.value) {
              showError(username, 'Username cannot be empty');
              hasErrors = true;
          } else if (!/^[a-zA-Z0-9_]{3,20}$/.test(username.value)) {
              showError(username, 'Username can only contain letters, numbers, and underscores (3-20 characters)');
              hasErrors = true;
          }
          
          // Check email
          if (!email.value) {
              showError(email, 'Email cannot be empty');
              hasErrors = true;
          } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
              showError(email, 'Please enter a valid email address');
              hasErrors = true;
          }
          
          if (!hasErrors) {
              // Save profile data
              const userData = JSON.parse(localStorage.getItem('userData')) || {};
              userData.displayName = displayName.value;
              userData.username = username.value;
              userData.email = email.value;
              userData.bio = document.getElementById('bio').value;
              userData.location = document.getElementById('location').value;
              userData.website = document.getElementById('website').value;
              
              localStorage.setItem('userData', JSON.stringify(userData));
              
              // Update sidebar profile
              document.querySelectorAll('.profile-info h3').forEach(el => {
                  el.textContent = userData.displayName;
              });
              
              document.querySelectorAll('.profile-info p').forEach(el => {
                  el.textContent = '@' + userData.username;
              });
              
              // Show success message
              const successMessage = document.createElement('div');
              successMessage.className = 'profile-success';
              successMessage.textContent = 'Profile updated successfully';
              successMessage.style.color = 'var(--success-color)';
              successMessage.style.marginTop = '10px';
              profileForm.after(successMessage);
              
              // Remove success message after 3 seconds
              setTimeout(() => {
                  successMessage.remove();
              }, 3000);
          }
          
          function showError(element, message) {
              const errorMessage = document.createElement('div');
              errorMessage.className = 'profile-error';
              errorMessage.textContent = message;
              errorMessage.style.color = 'var(--danger-color)';
              errorMessage.style.fontSize = '12px';
              errorMessage.style.marginTop = '5px';
              
              element.style.borderColor = 'var(--danger-color)';
              element.parentNode.appendChild(errorMessage);
              
              // Clear error state on input
              element.addEventListener('input', function() {
                  this.style.borderColor = '';
                  const error = this.parentNode.querySelector('.profile-error');
                  if (error) error.remove();
              }, { once: true });
          }
      });
  }
}

// API Key Management Function
function initAPIKeyManagement() {
  // Reset API key button
  const resetButton = document.querySelector('.api-key .btn-danger');
  if (resetButton) {
      resetButton.addEventListener('click', function() {
          // Confirm reset
          if (confirm('Are you sure you want to reset your API key? All applications using this key will need to be updated.')) {
              // Get the key input
              const keyInput = this.closest('.api-key').querySelector('input');
              
              // Generate new key (in a real app this would be done on the server)
              const newKey = generateRandomApiKey();
              
              // Flash animation for the key
              keyInput.style.transition = 'background-color 0.3s ease';
              keyInput.style.backgroundColor = 'var(--primary-color-light)';
              
              setTimeout(() => {
                  // Update key value
                  keyInput.value = newKey;
                  keyInput.style.backgroundColor = '';
                  
                  // Show notification
                  const notification = document.createElement('div');
                  notification.className = 'notification';
                  notification.textContent = 'API key has been reset';
                  notification.style.position = 'fixed';
                  notification.style.top = '20px';
                  notification.style.right = '20px';
                  notification.style.backgroundColor = 'var(--success-color)';
                  notification.style.color = 'white';
                  notification.style.padding = '10px 20px';
                  notification.style.borderRadius = 'var(--border-radius)';
                  notification.style.zIndex = '1000';
                  notification.style.opacity = '0';
                  notification.style.transition = 'opacity 0.3s ease';
                  
                  document.body.appendChild(notification);
                  
                  setTimeout(() => {
                      notification.style.opacity = '1';
                  }, 100);
                  
                  setTimeout(() => {
                      notification.style.opacity = '0';
                      setTimeout(() => notification.remove(), 300);
                  }, 3000);
              }, 200);
          }
      });
  }
  
  // Generate new API key button
  const generateButton = document.querySelector('.api-section .btn-primary');
  if (generateButton) {
      generateButton.addEventListener('click', function() {
          // In a real app, this would send a request to the server
          // For this demo, we'll simulate adding a new key
          
          const apiKeys = document.querySelector('.api-keys');
          const newKey = generateRandomApiKey();
          
          const keyElement = document.createElement('div');
          keyElement.className = 'api-key';
          keyElement.innerHTML = `
              <div class="key-info">
                  <h4>Secondary API Key</h4>
                  <div class="key-value">
                      <input type="password" value="${newKey}" disabled>
                      <button class="btn-icon toggle-visibility"><i class="fas fa-eye"></i></button>
                  </div>
              </div>
              <div class="key-actions">
                  <button class="btn btn-sm btn-outline">Copy</button>
                  <button class="btn btn-sm btn-danger">Reset</button>
              </div>
          `;
          
          apiKeys.appendChild(keyElement);
          
          // Re-initialize password visibility for the new key
          initPasswordVisibilityToggle();
          
          // Add animation
          keyElement.style.animation = 'fadeIn 0.3s forwards';
      });
  }
  
  function generateRandomApiKey() {
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < 16; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
  }
}

// Notification Effects Function
function initNotificationEffects() {
  // Add animation to notification cards
  document.querySelectorAll('.toggle-option').forEach(option => {
      const toggle = option.querySelector('input[type="checkbox"]');
      
      if (toggle) {
          toggle.addEventListener('change', function() {
              // Flash effect on change
              const parent = this.closest('.toggle-option');
              parent.style.transition = 'background-color 0.3s ease';
              
              if (this.checked) {
                  parent.style.backgroundColor = 'var(--primary-color-light)';
              } else {
                  parent.style.backgroundColor = 'var(--card-hover-bg)';
              }
              
              setTimeout(() => {
                  parent.style.backgroundColor = '';
              }, 300);
          });
      }
  });
  
  // Add sounds for toggles if the audio context is available
  let audioContext;
  
  try {
      window.AudioContext = window.AudioContext || window.webkitAudioContext;
      audioContext = new AudioContext();
  } catch (e) {
      console.log('Web Audio API is not supported in this browser');
  }
  
  if (audioContext) {
      document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
          checkbox.addEventListener('change', function() {
              // Create a sound
              const oscillator = audioContext.createOscillator();
              const gainNode = audioContext.createGain();
              
              oscillator.connect(gainNode);
              gainNode.connect(audioContext.destination);
              
              // Set sound properties based on checked state
              if (this.checked) {
                  oscillator.type = 'sine';
                  oscillator.frequency.value = 800;
                  gainNode.gain.value = 0.1;
              } else {
                  oscillator.type = 'sine';
                  oscillator.frequency.value = 600;
                  gainNode.gain.value = 0.1;
              }
              
              // Play the sound
              oscillator.start();
              
              // Stop after a short duration
              setTimeout(() => {
                  oscillator.stop();
              }, 150);
          });
      });
  }
}

// Add interactive animations
function initAnimations() {
  // Add hover effects to buttons
  document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-1px)';
      });
      
      btn.addEventListener('mouseleave', function() {
          this.style.transform = '';
      });
  });
  
  // Add card animations
  document.querySelectorAll('.theme-card, .plan-card, .integration-card').forEach(card => {
      card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-3px)';
          this.style.boxShadow = '0 8px 15px rgba(0,0,0,0.1)';
      });
      
      card.addEventListener('mouseleave', function() {
          this.style.transform = '';
          this.style.boxShadow = '';
      });
  });
  
  // Add ripple effect to buttons
  document.querySelectorAll('.btn').forEach(button => {
      button.addEventListener('click', function(e) {
          const x = e.clientX - e.target.getBoundingClientRect().left;
          const y = e.clientY - e.target.getBoundingClientRect().top;
          
          const ripple = document.createElement('span');
          ripple.className = 'ripple';
          ripple.style.left = `${x}px`;
          ripple.style.top = `${y}px`;
          
          this.appendChild(ripple);
          
          setTimeout(() => {
              ripple.remove();
          }, 600);
      });
  });
}

// Search functionality
function initSearchFunctionality() {
  const searchInput = document.querySelector('.search-bar input');
  
  if (searchInput) {
      searchInput.addEventListener('input', function() {
          const searchTerm = this.value.toLowerCase();
          
          if (searchTerm.length > 0) {
              // Search in settings headers and content
              const allSettingsSections = document.querySelectorAll('.settings-section');
              const allNavigationItems = document.querySelectorAll('.settings-nav li');
              
              let foundResults = false;
              
              // Reset highlight
              document.querySelectorAll('.search-highlight').forEach(el => {
                  el.outerHTML = el.innerHTML;
              });
              
              // Hide all sections first
              allSettingsSections.forEach(section => {
                  section.classList.remove('active');
                  section.style.display = 'none';
              });
              
              // Reset navigation active state
              allNavigationItems.forEach(item => {
                  item.classList.remove('active');
              });
              
              // Search and highlight matches
              allSettingsSections.forEach(section => {
                  const sectionContent = section.innerHTML.toLowerCase();
                  
                  if (sectionContent.includes(searchTerm)) {
                      // Show this section
                      section.style.display = 'block';
                      foundResults = true;
                      
                      // Activate the navigation item
                      const sectionId = section.id;
                      const navItem = document.querySelector(`.settings-nav li[data-section="${sectionId}"]`);
                      if (navItem) {
                          navItem.classList.add('active');
                      }
                      
                      // Highlight matches
                      highlightMatches(section, searchTerm);
                  }
              });
              
              // Show message if no results
              let noResultsMsg = document.querySelector('.no-search-results');
              
              if (!foundResults) {
                  if (!noResultsMsg) {
                      noResultsMsg = document.createElement('div');
                      noResultsMsg.className = 'no-search-results';
                      noResultsMsg.textContent = 'No settings found matching your search';
                      noResultsMsg.style.padding = '20px';
                      noResultsMsg.style.textAlign = 'center';
                      noResultsMsg.style.color = 'var(--text-muted)';
                      
                      document.querySelector('.settings-content').appendChild(noResultsMsg);
                  }
              } else if (noResultsMsg) {
                  noResultsMsg.remove();
              }
          } else {
              // Reset to default view if search is cleared
              resetSearchState();
          }
      });
      
      // Clear button
      const searchIcon = document.querySelector('.search-bar i');
      if (searchIcon) {
          searchIcon.addEventListener('click', function() {
              searchInput.value = '';
              resetSearchState();
              
              // Focus the input
              searchInput.focus();
          });
      }
      
      function resetSearchState() {
          // Remove highlights
          document.querySelectorAll('.search-highlight').forEach(el => {
              el.outerHTML = el.innerHTML;
          });
          
          // Reset sections visibility
          document.querySelectorAll('.settings-section').forEach(section => {
              section.style.display = '';
          });
          
          // Restore active section
          const activeNavItem = document.querySelector('.settings-nav li.active');
          if (activeNavItem) {
              activeNavItem.click();
          } else {
              // Default to profile if nothing is active
              document.querySelector('.settings-nav li[data-section="profile"]').click();
          }
          
          // Remove no results message
          const noResultsMsg = document.querySelector('.no-search-results');
          if (noResultsMsg) {
              noResultsMsg.remove();
          }
      }
      
      function highlightMatches(element, term) {
          // Text nodes that contain the search term
          const walker = document.createTreeWalker(
              element,
              NodeFilter.SHOW_TEXT,
              {
                  acceptNode: function(node) {
                      if (node.parentNode.nodeName !== 'SCRIPT' && 
                          node.parentNode.nodeName !== 'STYLE' &&
                          !node.parentNode.classList.contains('search-highlight') &&
                          node.textContent.toLowerCase().includes(term)) {
                          return NodeFilter.FILTER_ACCEPT;
                      }
                      return NodeFilter.FILTER_SKIP;
                  }
              }
          );
          
          const nodesToReplace = [];
          let currentNode;
          
          while (currentNode = walker.nextNode()) {
              nodesToReplace.push(currentNode);
          }
          
          for (let i = 0; i < nodesToReplace.length; i++) {
              const node = nodesToReplace[i];
              const text = node.textContent;
              const lowerText = text.toLowerCase();
              let startIndex = 0;
              let index;
              
              // Create a document fragment for the new content
              const fragment = document.createDocumentFragment();
              
              while ((index = lowerText.indexOf(term, startIndex)) > -1) {
                  // Add the text before the match
                  fragment.appendChild(document.createTextNode(text.substring(startIndex, index)));
                  
                  // Add the highlighted match
                  const highlight = document.createElement('span');
                  highlight.className = 'search-highlight';
                  highlight.style.backgroundColor = 'var(--primary-color-light)';
                  highlight.style.padding = '0 2px';
                  highlight.style.borderRadius = '3px';
                  highlight.textContent = text.substring(index, index + term.length);
                  fragment.appendChild(highlight);
                  
                  startIndex = index + term.length;
              }
              
              // Add any remaining text
              if (startIndex < text.length) {
                  fragment.appendChild(document.createTextNode(text.substring(startIndex)));
              }
              
              // Replace the original node with the fragment
              node.parentNode.replaceChild(fragment, node);
          }
      }
  }
}

// Session timeout warning
function initSessionTimeoutWarning() {
  // Already implemented in initSessionManagement
}